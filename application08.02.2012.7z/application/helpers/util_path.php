<?php
    define('ECOMMERCE', 'index.php');
?>