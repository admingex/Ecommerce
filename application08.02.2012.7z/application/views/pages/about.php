<div id="container">
	<h1>Welcome to e-commerce CodeIgniter version!</h1>
	
	<div id="body">
		<p>About.</p>

		<code>printf("About Page!");</code>
		
		<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds</p>
</div>
