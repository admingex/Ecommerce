<div id="container">
	<h1><?php echo $subtitle; ?></h1>

	<div id="body">
		<p> Home page</p>

		
		<code>printf("Hello World!");</code>
		
		<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds</p>
	</div>
</div>
